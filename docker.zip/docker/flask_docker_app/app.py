from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Home</title>
    </head>
    <body>
        <h1>Bem-vindo ao Flask Web App!</h1>
        <p><a href="/time">Ver a hora atual</a></p>
        <p><a href="/greet?name=SeuNome">Enviar uma saudação</a></p>
    </body>
    </html>
    '''

@app.route('/time')
def time():
    now = datetime.now()
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Hora Atual</title>
    </head>
    <body>
        <h1>Hora Atual</h1>
        <p>Agora é: {now.strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p><a href="/">Voltar para a página inicial</a></p>
    </body>
    </html>
    '''

@app.route('/greet')
def greet():
    name = request.args.get('name', 'Visitante')
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Saudação</title>
    </head>
    <body>
        <h1>Olá, {name}!</h1>
        <p><a href="/">Voltar para a página inicial</a></p>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
